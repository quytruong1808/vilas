#!/bin/bash
java -Xmx1200m -cp lib -jar caver.jar -home . -pdb input -conf config.txt -out out 
