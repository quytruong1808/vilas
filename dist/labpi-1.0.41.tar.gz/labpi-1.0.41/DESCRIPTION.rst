Need software
0. Python version >= 2.7
1. Prody with Numpy and matlibplot
2. Gromacs version >= 4.6
3. Avogadro and Avogadro lib for python
4. Open babel
5. g_mmpbsa
http://rashmikumari.github.io/g_mmpbsa/Download-and-Installation.html

Request
0. Name of ligand file must have only 3 character, ec: A01, B02 v.v.v.
1. 
