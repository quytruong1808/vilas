Need software
1. Python version >= 2.7
sudo apt-get install python python-setuptools python-dev python-augeas

2. Gromacs version >= 4.6
sudo apt-get install gromacs

3. Openbabel
sudo apt-get install openbabel

4. Avogadro for python
sudo apt-get install avogadro

5. Cython
sudo apt-get install cython

6. Another package
sudo apt-get installgcc swig dialog

sudo apt-get install xmlsec1 openssl python-lxml libxmlsec1 libxmlsec1-dev

sudo apt-get install build-essential autoconf libtool pkg-config python-opengl python-imaging python-pyrex python-pyside.qtopengl idle-python2.7 qt4-dev-tools qt4-designer libqtgui4 libqtcore4 libqt4-xml libqt4-test libqt4-script libqt4-network libqt4-dbus python-qt4 python-qt4-gl libgle3 python-dev